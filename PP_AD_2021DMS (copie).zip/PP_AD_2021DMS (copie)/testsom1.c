#include<stdio.h>
#include<mpi.h>
#include<time.h>

int main(int argc, char ** argv){

int node;
   double mytime;   /*declare a variable to hold the time returned*/
   
    int i,sum,sumTotal,upToVal,rank,size,start,end;
 
    upToVal = 10,0;
    MPI_Init(&argc,&argv);
    
    mytime = MPI_Wtime();
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    MPI_Comm_size(MPI_COMM_WORLD,&size);
    start = rank * (upToVal/size) + 1;
    if(rank == size - 1){
        end = upToVal;
    }else{
        end = start + (upToVal/size) - 1;
    }
    
  
    
    sum = 0;
    sumTotal = 0;
    
   
    for(i=start;i<=end;i++){
        sum = sum + i;
        
       mytime = MPI_Wtime() - mytime;
    }
     
    
     
    MPI_Reduce(&sum,&sumTotal,1,MPI_INT,MPI_SUM,0,MPI_COMM_WORLD);
    
    
    printf("Le rank est %d, la somme est %d, et la sumTotal est: %d \n",rank,sum,sumTotal);
   
    printf("Timing from node %d is %lf seconds.\n",node,mytime);
    MPI_Finalize();
    
    return 0;
} 

